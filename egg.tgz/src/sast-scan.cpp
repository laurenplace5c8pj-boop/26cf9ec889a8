// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("sast scan"); }
int main(){
  announce();
  return lionss_run_workload("sast-scan");
}
