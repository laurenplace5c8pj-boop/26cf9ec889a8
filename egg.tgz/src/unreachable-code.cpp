// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("unreachable code"); }
int main(){
  announce();
  return lionss_run_workload("unreachable-code");
}
