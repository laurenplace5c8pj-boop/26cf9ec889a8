// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("unit tests"); }
int main(){
  announce();
  return lionss_run_workload("unit-tests");
}
