// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("source tarball\n", stdout);
  return lionss_run_workload("source-tarball");
}
