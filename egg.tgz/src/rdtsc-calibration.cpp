// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("rdtsc calibration"); }
int main(){
  announce();
  return lionss_run_workload("rdtsc-calibration");
}
